# Products API

REST API built with Spring Boot to manage products through CRUD operations.

## Technologies

- Java 21
- Spring Boot 4.1.1
- Spring Web MVC
- Spring Data JPA
- Jakarta Validation
- H2 Database
- Springdoc OpenAPI and Swagger UI
- Maven Wrapper

## Architecture

The application uses a layered architecture:

- Entity: represents the product and its validation constraints.
- Repository: accesses the database through Spring Data JPA.
- Service: handles product operations and checks whether products exist.
- Controller: exposes the REST endpoints and validates incoming requests.

## How to run

Open a terminal in the project directory and run:

```bash
chmod +x mvnw
./mvnw spring-boot:run
```

The API runs at http://localhost:8080.

Press Ctrl + C in the terminal to stop the application.

## Database

The application uses a file-based H2 database stored in the `data` directory.
Product data persists between application restarts.

H2 console: http://localhost:8080/h2-console

Connection settings:

- JDBC URL: `jdbc:h2:file:./data/products`
- Username: `sa`
- Password: leave empty

## API reference

The GET `/api/products` endpoint returns a list of all stored products.
The GET `/api/products/{id}` endpoint returns one product by its ID, or HTTP 404 if it does not exist.
The POST `/api/products` endpoint creates a product and returns HTTP 201 with the generated ID.
The PUT `/api/products/{id}` endpoint updates an existing product and returns HTTP 200 with its updated data.
The DELETE `/api/products/{id}` endpoint deletes an existing product and returns HTTP 204 with no response body.
POST and PUT requests return HTTP 400 when the product name is blank or the price is missing or less than 0.01.

## Request example

Use this JSON body to create or update a product:

```json
{
  "name": "Keyboard",
  "description": "USB keyboard",
  "price": 85000
}
```

## Swagger documentation

Swagger UI: http://localhost:8080/swagger-ui.html

OpenAPI JSON: http://localhost:8080/v3/api-docs

## Postman verification

The following requests were manually verified:

| Operation | Method | Endpoint | Expected status |
|---|---|---|---|
| Create product | POST | /api/products | 201 Created |
| List products | GET | /api/products | 200 OK |
| Get product | GET | /api/products/{id} | 200 OK |
| Update product | PUT | /api/products/{id} | 200 OK |
| Delete product | DELETE | /api/products/{id} | 204 No Content |
| Get deleted product | GET | /api/products/{id} | 404 Not Found |
| Create invalid product | POST | /api/products | 400 Bad Request |

For the invalid request, an empty name and a negative price were submitted:

```json
{
  "name": "",
  "description": "Invalid product",
  "price": -100
}
```
