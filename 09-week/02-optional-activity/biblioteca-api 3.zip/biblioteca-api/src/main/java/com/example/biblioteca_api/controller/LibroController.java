package com.example.biblioteca_api.controller;

import java.net.URI;
import java.util.List;

import jakarta.validation.Valid;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.biblioteca_api.entity.Libro;
import com.example.biblioteca_api.service.LibroService;

@RestController
@RequestMapping("/api/libros")
public class LibroController {

    private final LibroService libroService;

    public LibroController(LibroService libroService) {
        this.libroService = libroService;
    }

    @GetMapping
    public List<Libro> listar() {
        return libroService.listar();
    }

    @GetMapping("/{id}")
    public Libro obtenerPorId(@PathVariable("id") Long id) {
        return libroService.obtenerPorId(id);
    }

    @PostMapping
    public ResponseEntity<Libro> crear(
            @Valid @RequestBody Libro libro) {

        Libro creado = libroService.crear(libro);

        URI ubicacion = URI.create("/api/libros/" + creado.getId());

        return ResponseEntity.created(ubicacion).body(creado);
    }

    @PutMapping("/{id}")
    public Libro actualizar(
            @PathVariable("id") Long id,
            @Valid @RequestBody Libro libro) {

        return libroService.actualizar(id, libro);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(
            @PathVariable("id") Long id) {

        libroService.eliminar(id);

        return ResponseEntity.noContent().build();
    }
}