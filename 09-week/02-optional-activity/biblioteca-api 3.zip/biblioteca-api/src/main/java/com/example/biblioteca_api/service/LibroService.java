package com.example.biblioteca_api.service;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import com.example.biblioteca_api.entity.Libro;
import com.example.biblioteca_api.repository.LibroRepository;

@Service
public class LibroService {

    private final LibroRepository libroRepository;

    public LibroService(LibroRepository libroRepository) {
        this.libroRepository = libroRepository;
    }

    public List<Libro> listar() {
        return libroRepository.findAll();
    }

    public Libro obtenerPorId(Long id) {
        return libroRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "No existe un libro con el ID " + id
                ));
    }

    public Libro crear(Libro libro) {
        libro.setId(null);
        return libroRepository.save(libro);
    }

    public Libro actualizar(Long id, Libro datos) {
        Libro libro = obtenerPorId(id);

        libro.setTitulo(datos.getTitulo());
        libro.setAutor(datos.getAutor());
        libro.setAnioPublicacion(datos.getAnioPublicacion());

        return libroRepository.save(libro);
    }

    public void eliminar(Long id) {
        Libro libro = obtenerPorId(id);
        libroRepository.delete(libro);
    }
}