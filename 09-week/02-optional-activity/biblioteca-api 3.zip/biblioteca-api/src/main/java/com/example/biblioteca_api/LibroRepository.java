package com.example.biblioteca_api.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.biblioteca_api.entity.Libro;

public interface LibroRepository extends JpaRepository<Libro, Long> {

    List<Libro> findByAutorIgnoreCase(String autor);
}