# Biblioteca API — Semana 8

API REST desarrollada con Spring Boot para administrar libros.

## Tecnologías

- Java 21
- Spring Boot
- Spring Web MVC
- Spring Data JPA
- Bean Validation
- H2 Database
- Maven

## Arquitectura por capas

- entity/Libro.java: representa la tabla libros y valida sus atributos.
- repository/LibroRepository.java: proporciona acceso a la base de datos.
- service/LibroService.java: implementa las operaciones CRUD.
- controller/LibroController.java: recibe las peticiones HTTP y devuelve las respuestas.

## Cómo ejecutar

Se necesita Java 21 o una versión compatible y conexión a internet
para descargar las dependencias inicialmente.

Desde una terminal dentro del proyecto, ejecutar:

```bash
chmod +x mvnw
./mvnw spring-boot:run
```

La API estará disponible en:

http://localhost:8080/api/libros

La base de datos H2 se guarda en la carpeta data y conserva los registros
al reiniciar la aplicación.

Para detener la aplicación, presionar Ctrl + C en la terminal.

## Endpoints

| Método | URL | Acción | Respuesta exitosa |
|---|---|---|---|
| POST | /api/libros | Crear un libro | 201 Created |
| GET | /api/libros | Listar todos los libros | 200 OK |
| GET | /api/libros/{id} | Obtener un libro por ID | 200 OK |
| PUT | /api/libros/{id} | Actualizar un libro existente | 200 OK |
| DELETE | /api/libros/{id} | Eliminar un libro | 204 No Content |

Las URLs utilizan el sustantivo libros y cada acción usa el método HTTP correspondiente.

## Ejemplo para crear un libro

Enviar POST a /api/libros con Content-Type: application/json.

```json
{
  "titulo": "Cien años de soledad",
  "autor": "Gabriel García Márquez",
  "anioPublicacion": 1967
}
```

El identificador se genera automáticamente.

## Validaciones y errores

- El título y el autor son obligatorios y no pueden estar en blanco.
- El año de publicación es obligatorio y debe ser mayor que cero.
- Los datos que incumplen las validaciones producen 400 Bad Request.
- Consultar, actualizar o eliminar un ID inexistente produce 404 Not Found.

## Pruebas realizadas en Postman

1. Crear un libro mediante POST y comprobar la respuesta 201.
2. Listar los libros mediante GET y comprobar la respuesta 200.
3. Consultar el libro creado por su ID y comprobar la respuesta 200.
4. Actualizar sus datos mediante PUT y comprobar la respuesta 200.
5. Consultarlo nuevamente para verificar que los cambios quedaron guardados.
6. Eliminarlo mediante DELETE y comprobar la respuesta 204.
7. Consultar el ID eliminado y comprobar la respuesta 404.

En las pruebas por ID se utiliza el identificador devuelto al crear el libro.

